/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Eddie
 */
public class Order {
    int aud = 0;
    int adults = 0;
    int senior = 0;
    int child = 0;
    int sum = 0;
    int[] rows;
    int[] seats;
    char[] types;
    
}
